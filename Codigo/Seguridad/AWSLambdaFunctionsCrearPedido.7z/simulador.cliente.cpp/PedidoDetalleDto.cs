﻿    public class PedidoDetalleDto
    {
        public int ProductoId { get; set; }
        public int Cantidad { get; set; }

    }
